<?
//include($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
include($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mail/include.php");
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/php_interface/include/PHPExcel.php");
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/php_interface/include/PHPExcel/IOFactory.php");
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/php_interface/include/SettingsList.php");
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/php_interface/include/PHPMailer/PHPMailerAutoload.php");
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/php_interface/include/NameCase/NCLNameCaseRu.php");
require_once($_SERVER['DOCUMENT_ROOT']."/crm/SummProp.php");
require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/php_interface/include/PHPWord.php");
//IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/intranet/public/crm/deal/index.php");

global $USER;
global $APPLICATION;
global $USER_FIELD_MANAGER;

$GLOBALS['flagCompany']=0;
use Bitrix\Main,
	Bitrix\Main\Localization\Loc,
	Bitrix\Main\Loader,
	Bitrix\Sale,
	Bitrix\Main\Application;

	Loader::IncludeModule("iblock");
	Loader::IncludeModule("crm");
	Loader::IncludeModule("tasks");
	Loader::IncludeModule("disk");
	Loader::IncludeModule("bizproc");
	Loader::IncludeModule("im");
	Loader::IncludeModule("socialnetwork");
	
	mb_internal_encoding('latin1');
	
CModule::IncludeModule('sale');
echo "<pre>";
//$arEntityIds = CCrmFields::GetFieldTypes();

	$GLOBALS['text']='';
	//$GLOBALS['Template']='Договор на оказание услуг.docx';

$entity='INVOICE';
$id=803;
function getRusName($name){
		$arr=[
			'INVOICE'=>'Счет',
			'DEAL'=>'Сделка',
			'COMPANY'=>'Компания',
			'CONTACT'=>'Контакт',
			
			'MYCOMPANY'=>'Моя компания',
			'REQUISITE_ID'=>'Контрагент.Реквизиты',
			'BANK_DETAIL_ID'=>'Контрагент.Реквизиты.Банковские реквизиты',
			'MC_REQUISITE_ID'=>'Реквизиты вашей компании.Реквизиты',
			'MC_BANK_DETAIL_ID'=>'Реквизиты вашей компании.Реквизиты.Банковские реквизиты',
			
		];
	foreach($arr as $key=>$value){
		if($name==$key){
			$rusName=$value;
			break;
		}
		else $rusName=null;
	}
	return $rusName;
}
function getEntityMapUnit($entity,$id){
	global $USER_FIELD_MANAGER;
	$entityType=('INVOICE'==$entity)?'ORDER':'CRM_'.$entity;
	$arUserFields=(new CCrmFields($USER_FIELD_MANAGER, $entityType))->GetFields();
	//print_r($arUserFields);
	$entityCRM='CCrm'.$entity;
	$entityObj=(new $entityCRM);
	$RusName=getRusName($entity);
	
	$RequestBd=$entityObj->GetList(array(), array("ID"=>$id))->Fetch();
	if(!empty($RequestBd)){
		foreach($RequestBd as $key=>$value)
			{
				$CaptionFieldName = $entityObj->GetFieldCaption($key);
				$CaptionUserFieldName = $arUserFields[$key]["EDIT_FORM_LABEL"];			
				$CaptionField = $RusName.'.'.$CaptionFieldName."";
				$CaptionUserField = $RusName.'.'.$CaptionUserFieldName."";
				if($CaptionFieldName && !array_key_exists($CaptionField, ($arEntity)?$arEntity:[]))
				{
					$arEntity[$CaptionField] = ['FIELD'=>$key,'VALUE'=>$value];
				}
				elseif($CaptionUserFieldName && !array_key_exists($CaptionUserField, ($arEntity)?$arEntity:[]))
				{
					$arEntity[$CaptionUserField] = ['FIELD'=>$key,'VALUE'=>$value];
				}
				
				switch ($key) {
					case "UF_DEAL_ID":
						if($value!=0&&$value!=''){
							$arEntity=array_merge(getEntityMapUnit('DEAL',$value),$arEntity);
						}
					    break;
					case "UF_CONTACT_ID":
						if($value!=0&&$value!=''){
						echo $value;
							$arEntity=array_merge(getEntityMapUnit('CONTACT',$value),$arEntity);
						}
					    break;
					case "UF_COMPANY_ID":
						if($value!=0&&$value!=''){
							$arEntity=array_merge(getEntityMapUnit('COMPANY',$value),$arEntity);
							foreach($arEntity as $key => $value){
									if($value['FIELD']=='TITLE'){
										$GLOBALS['CompanyName']=$value['VALUE'];
									}
								}
								$GLOBALS['flagCompany']=1;
						}
					    break;
					case "COMPANY_ID":
						if($GLOBALS['flagCompany']==0){
							if($value!=0&&$value!=''){
								
								$arEntity=array_merge(getEntityMapUnit('COMPANY',$value),$arEntity);
								foreach($arEntity as $key => $value){
									if($value['FIELD']=='TITLE'){
										$GLOBALS['CompanyName']=$value['VALUE'];
									}
								}
								$GLOBALS['flagCompany']=1;
							}
						}
					    break;
					case "UF_MYCOMPANY_ID":
						if($value!=0&&$value!=''){
							$arMycompany=getEntityMapUnit('COMPANY',$value);

							$keyCOMPANY=getRusName('COMPANY');
							$keyMYCOMPANY=getRusName('MYCOMPANY');
							foreach($arMycompany as $key => $value){
								/*if($value['FIELD']=='TITLE'){
									$GLOBALS['CompanyName']=$value['VALUE'];
								}*/
								$arMycompanyFiltered[str_replace($keyCOMPANY,$keyMYCOMPANY,$key)]=$value;
							}
							$arEntity=array_merge($arMycompanyFiltered,$arEntity);
						}
					    break;
					}
			}
	}
	$ArrayRequisite=PrepareRequisiteList($entity,$id);
	if(!empty($ArrayRequisite)){
		foreach($ArrayRequisite as $key => $value){
			$newArrayRequisite[$RusName.'.'.$key] = $value;
		}
		$arEntity=(!empty($arEntity))?array_merge($newArrayRequisite,$arEntity):$newArrayRequisite;
	}
	return $arEntity;
}
function EntityRequisite($entity,$id){		
	if($entity=='INVOICE'){
		$requisiteBindings = Bitrix\Crm\Requisite\EntityLink::getByEntity(CCrmOwnerType::Invoice,$id);
		return $requisiteBindings;
	}
	elseif($entity=='DEAL'){
		$requisiteBindings = Bitrix\Crm\Requisite\EntityLink::getByEntity(CCrmOwnerType::Deal,$id);
		return $requisiteBindings;
	}
}
function PrepareRequisiteList($entity,$id){
	if($entity=='INVOICE'||$entity=='DEAL'){
		$BankRequisite = new \Bitrix\Crm\EntityBankDetail();
		$Requisite = new \Bitrix\Crm\EntityRequisite();
		$arrntityRequisite = array();
		$arrntityRequisite=EntityRequisite($entity,$id);
		if($arrntityRequisite){
			foreach ($arrntityRequisite as $key => $value){
				echo '<br>';
				//print_r($value);
				if(strripos($key, 'BANK')!==false&&$value!=0){
					$key=getRusName($key);
					$result=PrepareRequisiteArrRus($BankRequisite->getById((int)$value),$BankRequisite);
					foreach($result as $name => $value){
						$arrRequisite[$key.'.'.$name]=$value;
					}
				}
				elseif(strripos($key,'REQUISITE')!==false&&$value!=0) {
					$key=getRusName($key);
					$result=PrepareRequisiteArrRus($Requisite->getById((int)$value),$Requisite);
					$address = PrepareRequisiteAddressRus($Requisite->getAddresses((int)$value));
					foreach($result as $name => $value){
						$arrRequisite[$key.'.'.$name]=$value;
					}
					if(!empty($address)){
						foreach($address as $name2 => $value2){
							$arrRequisite[$key.'.'.$name2]=$value2;
						}
					}
				}
			}
		}
	return $arrRequisite;
	}
}
function PrepareRequisiteArrRus($array,$obj){
	$requisiteTitle=$obj->getFieldsTitles();
	foreach($requisiteTitle as $key => $value){
		if(array_key_exists($key,$array)){
			
			$result[$value]=['FIELD'=>$key,'VALUE'=>$array[$key]];	
		}
	}
	return $result;
}
function PrepareRequisiteAddressRus($array){
	$addressTitle=\Bitrix\Crm\EntityAddress::getLabels();
	$AddressTypes = \Bitrix\Crm\EntityAddressType::getAllDescriptions();
		foreach($array as $key => $value){
			foreach($value as $key2 => $value2){
			$result[$AddressTypes[$key].'.'.$addressTitle[$key2]]=['FIELD'=>$key2,'VALUE'=>$value2];
		}
	}
	return $result;
}
function UpdateArrayValue($array){
	global $USER;
	$arrUpdate=[
		'DATE_CREATE' => 'DATE',
		'DATE_MODIFY' => 'DATE',
		'CREATED_BY_ID' => 'USER',
		'MODIFY_BY_ID' => 'USER',
		'RESPONSIBLE_ID' => 'USER',
		'ASSIGNED_BY_ID' => 'USER',
		    ];
	foreach($array as $key => $value){
		foreach($arrUpdate as $fildName => $obj){
			if($fildName==$value['FIELD']){
				if($obj=='DATE'){
				
				$arrayNEW[$key]=CCrmComponentHelper::TrimDateTimeString(ConvertTimeStamp(MakeTimeStamp($value['VALUE']),'SHORT', SITE_ID));
				break;
				}
				if($obj=='USER'){
					$user=$USER->GetByID($value['VALUE'])->Fetch();
					$arrayNEW[$key]=$user['LAST_NAME'].' '.$user['NAME'].' '.$user['SECOND_NAME'];
					break;
				}
			}
			elseif($fildName!=$value['FIELD']){
				if(!is_array($value['VALUE'])){
					if(strlen($value['VALUE'])>0){
						$arrayNEW[$key]=$value['VALUE'];
					}
				}
			}
		}
		
	}
	return $arrayNEW;
}
function GetProductList($entity,$id){
	if($entity=='INVOICE'){
		$arrayProduct[$entity] = CCrmInvoice::GetProductRows($id);
		return $arrayProduct;
	}
	elseif($entity=='DEAL'){
		$arrayProduct[$entity] = CCrmDeal::LoadProductRows($id);
		return $arrayProduct;
	}
}
function GetCIBLockRusName(){
	$arrCiblock=CIBlock::GetByID($GLOBALS['CIblockId'])->Fetch();
	return $arrCiblock['NAME'];
}



function getFoldersObject(){
	if($GroupId=getCSocNetGroupID()){
		$groupStorage = \Bitrix\Disk\Driver::getInstance() -> getStorageByGroupId($GroupId);
		$FolderGroup = $groupStorage -> getRootObject();
		$FolderTemplates = $FolderGroup -> getChild(
			[
				'=NAME' => 'Шаблоны',
				'TYPE' => \Bitrix\Disk\Internals\FolderTable::TYPE_FOLDER
			]
		);
		if($FolderTemplates){
			return $arrFolder = ['FolderGroup' => $FolderGroup,'FolderTemplates' => $FolderTemplates];
		}
		else {
			$FolderTemplates = $FolderGroup -> addSubFolder([
				'NAME' => 'Шаблоны',
				'CREATED_BY' => 1
			]);
			return $arrFolder = ['FolderGroup' => $FolderGroup,'FolderTemplates' => $FolderTemplates];
		}
	}
}

function getCSocNetGroupID(){
	$arFilter=['NAME' => GetCIBLockRusName()];
	$resDB = CSocNetGroup::GetList([],$arFilter)->Fetch();
	if (count($resDB)>0){
		$ID=$resDB['ID'];
	}
	else{
		$arFields = [
			"SITE_ID" => SITE_ID,
			"NAME" => GetCIBLockRusName(),
			"DESCRIPTION" => 'Группа документооборота',
			"VISIBLE" => "Y" ,
			"OPENED" => "Y" ,
			"CLOSED" =>  "N",
			"SUBJECT_ID" => 1,
			"KEYWORDS" => 'Документооборот',
			"INITIATE_PERMS" => "K",
			"SPAM_PERMS" => "K",
		];
		$ID = CSocNetGroup::CreateGroup(1, $arFields);
	}
	return $ID;
}
function GetFileObj($FileName,$FolderObj){
	$File=$FolderObj->getChild(
		[
			'=NAME' => $FileName,
			'TYPE' => \Bitrix\Disk\Internals\FileTable::TYPE_FILE
		]);
	return $File;
}
function GetFolderOrCreate($RootFolder,$name){
	$GetFolder = $RootFolder -> getChild(
		[
			'=NAME' => $name,
			'TYPE' => \Bitrix\Disk\Internals\FolderTable::TYPE_FOLDER
		]
	);
	if($GetFolder){
		$folders=$GetFolder;
	}
	else{
		$folders = $RootFolder -> addSubFolder([
			'NAME' => $name,
			'CREATED_BY' => 1
		]);
	}
	return $folders;
}

function SetFileObj($FileName,$FolderObj){
	$fileArray = \CFile::MakeFileArray($_SERVER['DOCUMENT_ROOT'].'/upload/tmp/'.$FileName);
	$oldFile=$FolderObj->getChild(
		[
			'=NAME' => $FileName,
			'TYPE' => \Bitrix\Disk\Internals\FileTable::TYPE_FILE
		]);

	if($oldFile){
		$oldFile->delete(1);
		$FolderObj->uploadFile($fileArray,[ 'CREATED_BY' => 1]);
	}
	else{
		$FolderObj->uploadFile($fileArray, [ 'CREATED_BY' => 1]);
	}
	return $fileArray;
}
function UpdateTemplatesDocx($EntityRusArray,$file){
	$WordObj = new PHPWord();
	$name=$file->getFile()['ORIGINAL_NAME'];
	$document = $WordObj->loadTemplate($_SERVER['DOCUMENT_ROOT'].CFile::GetPath($file->getFileId()));
	foreach($EntityRusArray as $key=>$value)
	{
		$document->setValue($key, $value);
	}
	//print_r($document);
	//$document->setValue('Счет.Контрагент.Реквизиты.Создал', '42');
	//print_r($document);
	$save_file = $_SERVER['DOCUMENT_ROOT']."/upload/tmp/".$name;
	$document->save($save_file);
	return ['NAME'=>$name,"PATH_TO_FILE" => $save_file];
}

function UpdateTemplatesXLS($EntityRusArray,$file){
	//PHPExcel_Shared_Font::setAutoSizeMethod(PHPExcel_Shared_Font::AUTOSIZE_METHOD_EXACT);
	$name=$file->getFile()['ORIGINAL_NAME'];
	$objPHPExcel = PHPExcel_IOFactory::load($_SERVER['DOCUMENT_ROOT'].CFile::GetPath($file->getFileId()));
	
	$objWorksheet = $objPHPExcel->getActiveSheet();
	
	foreach ($objWorksheet->getRowIterator() as $row) {
		$cellIterator = $row->getCellIterator();
		$cellIterator->setIterateOnlyExistingCells;
		foreach ($cellIterator as $cell){
			foreach($EntityRusArray as $key=>$value){
				if($key!='ArrayProduct'){
					if (stristr($cell->getValue(), $key )){
							$changeValue = str_replace($key, $value, $cell->getValue());
							$cell->setValue($changeValue);
					}
				}
			}
		}
	}
	$objWorksheet=AddProductTableXLS($EntityRusArray['ArrayProduct'],$objWorksheet);
	$save_file = $_SERVER['DOCUMENT_ROOT']."/upload/tmp/".$name;
	//print_r($objPHPExcel);
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save($save_file);
	return ['NAME'=>$name,"PATH_TO_FILE" => $save_file];
}
function productExelTable($entity,$invoice_id){
	$Product = getProductR($entity,$invoice_id);
		$arProduct = [];
		$var1 = 0; $var2 = 0; $var3 = 0; $var4 = 0; $var5 = 0; $var6 = 0;
		$resT = [];
		foreach($Product as $key=>$value)
		{
				$arProduct[$key]["{!Товары.Номер}"] = ($key + 1);
				$arProduct[$key]["{!Товары.Наименование товара}"] = $value["PRODUCT_NAME"];
				$arProduct[$key]["{Товары.Наименование товара}"] = $value["PRODUCT_NAME"];
				$arProduct[$key]["{!Товары.Кол-во}"] = ''.+$value["QUANTITY"];
				$arProduct[$key]["{!Товары.Ед. измерения}"] = $value["MEASURE_NAME"];
				$arProduct[$key]["{!Товары.Скидка}"] = ''.+$value["DISCOUNT_PRICE"];
				$arProduct[$key]["{!Товары.Налог}"] = ''.+($value["VAT_RATE"]*100);
				$arProduct[$key]["{!Товары.Цена}"] = $value["PRICE"] + 0;
				$arProduct[$key]["{!Товары.Сумма скидки}"] = $value["QUANTITY"]*$value["DISCOUNT_PRICE"];
				$resT["{Товары.Всего товаров}"] = $arProduct[$key]["{!Товары.Номер}"];
				$var2 = $var2 + $arProduct[$key]["{!Товары.Итого}"];
				$resT["{Товары.Общая сумма}"] = $var2;
				$var3 = $var3 + $arProduct[$key]["{!Товары.Сумма без налога}"];
				$resT["{Товары.Сумма без налога}"] = $var3;
				$var4 = $var4 + $arProduct[$key]["{!Товары.Сумма налога}"];
				$resT["{Товары.Сумма налога}"] = $var4;
				$var5 = $var5 + $arProduct[$key]["{!Товары.Сумма без налога}"] + $arProduct[$key]["{!Товары.Сумма скидки}"];
				$resT["{Товары.Общая сумма без скидки и налога}"] = $var5;
				$var6 = $var6 + $arProduct[$key]["{!Товары.Сумма скидки}"];
				$resT["{Товары.Сумма скидки}"] = $var6;
				$arProduct[$key]["{!Товары.Картинка для анонса}"] = $value["PREVIEW_PICTURE"];
				$arProduct[$key]["{!Товары.Детальная картинка}"] = $value["DETAIL_PICTURE"];
			if ($value["VAT_INCLUDED"] == "Y")//налог входит в стоимость
			{

				$arProduct[$key]["{!Товары.Сумма налога}"] = round(($value["PRICE"]*100/(100 + $value["VAT_RATE"]*100))*$value["QUANTITY"]*$value["VAT_RATE"], 2);
				$arProduct[$key]["{!Товары.Итого}"] = $value["PRICE"]*$value["QUANTITY"];
				$arProduct[$key]["{!Товары.Сумма без налога}"] = $value["PRICE"]*$value["QUANTITY"] - $arProduct[$key]["{!Товары.Сумма налога}"];
				$resT["{Товары.Налог}"] = ''.+($value["VAT_RATE"]*100);
			}
			else//не входит
			{	
				$arProduct[$key]["{!Товары.Сумма налога}"] = round($value["PRICE"]*$value["QUANTITY"]*$value["VAT_RATE"], 2);
				$arProduct[$key]["{!Товары.Итого}"] = $value["PRICE"]*$value["QUANTITY"]*($value["VAT_RATE"]+1);
				$arProduct[$key]["{!Товары.Сумма без налога}"] = $value["PRICE"]*$value["QUANTITY"];
			}
		}
		//кастомности для особого счёта Александра
		if (!$arInvoice["{Счет.Сумма сделки}"])
			$arInvoice["{Счет.Сумма сделки}"] = 0;
		$resT["{Товары.Итого(РФ)}"] = 0;
		foreach($Product as $key=>$value)
		{	if($arInvoice["{Счет.Сумма сделки}"]!=0){
				$arProduct[$key]["{!Товары.Цена(РФ)}"] = ($value["PRICE"] + 0) * $resT["{Товары.Сумма без налога}"] / $arInvoice["{Счет.Сумма сделки}"];
				$arProduct[$key]["{!Товары.Итого(РФ)}"] = $value["PRICE"]*$value["QUANTITY"] * $resT["{Товары.Сумма без налога}"] / $arInvoice["{Счет.Сумма сделки}"];
				$resT["{Товары.Итого(РФ)}"] += $arProduct[$key]["{!Товары.Итого(РФ)}"];
			}
		}
		$resT["{Товары.Итого(РФ)}"] = round($resT["{Товары.Итого(РФ)}"], 2);
		///конец
		
		//////////////////////////////////////////функция суммы прописью
		if(!function_exists('mb_ucfirst'))
		{
			function mb_ucfirst($string, $enc = 'UTF-8')
			{
				return mb_strtoupper(mb_substr($string, 0, 1, $enc), $enc) . 
				mb_substr($string, 1, mb_strlen($string, $enc), $enc);
			}
		}
		///////////////////////////////////////////
		$resT["{Товары.Общая сумма.Прописью}"] = mb_ucfirst(num2str($resT["{Товары.Общая сумма}"]));
		$resT["{Товары.Сумма без налога.Прописью}"] = mb_ucfirst(num2str($resT["{Товары.Сумма без налога}"]));
		$resT["{Товары.Сумма налога.Прописью}"] = mb_ucfirst(num2str($resT["{Товары.Сумма налога}"]));
		$resT["{Товары.Итого(РФ).Прописью}"] = mb_ucfirst(num2str($resT["{Товары.Итого(РФ)}"]));
		
		return array_merge($resT,['ArrayProduct'=> $arProduct]);
}
function AddProductTableXLS($arProduct,$objWorksheet){
	
	if($arProduct)
		{
			$NextRow = 0;
			$Column = [];
			$mergeColumn = [];
			foreach($arProduct as $num => $arrV)
			{
				if($NextRow == 0)
				{
					foreach($arrV as $key=>$value)
					{
						$searchValue = $key;
						
						foreach ($objWorksheet->getRowIterator() as $row) 
						{
							
							$cellIterator = $row->getCellIterator();
							$cellIterator->setIterateOnlyExistingCells;
							foreach ($cellIterator as $cell) 
							{
								
								if (stristr( $cell->getValue(), $searchValue )) 
								{	
									if(stristr( $value , '/upload/iblock/')){
										$size = getimagesize ($_SERVER["DOCUMENT_ROOT"].$value);
										$objWorksheet->getRowDimension($cell->getRow())->setRowHeight($size[1]+20);
										$objWorksheet->getColumnDimension($cell->getColumn())->setWidth(($size[0]/5));
										$objDrawing = new PHPExcel_Worksheet_Drawing();
										$objDrawing->setName('Image');
										$objDrawing->setDescription('Image');
										$objDrawing->setPath($_SERVER["DOCUMENT_ROOT"].$value);
										$objDrawing->setWidth($size[0]);
										$objDrawing->setHeight($size[1]);
										$objDrawing->setCoordinates($cell->getCoordinate());
										$objDrawing->setOffsetX(20);
										$objDrawing->setOffsetY(20);
										$objDrawing->setWorksheet($objWorksheet);
										
										$objWorksheet->setCellValue($cell->getCoordinate(), '');
									}
									else{
										$objWorksheet->setCellValue($cell->getCoordinate(), $value);
									}
									$NextRow = $cell->getRow()+1;
									$Column[$searchValue] = $cell->getColumn();
									$mergeColumn[$searchValue]['First'] = $cell->getColumn();
									if($cell->getMergeRange())
									{	
										$my_merge = $cell->getMergeRange();										
										$ColumnR = $cell->getColumn();
										$RowR = $cell->getRow();
										
										while(1)
										{
											$LastColumn = $ColumnR;
											$ColumnR++;
											$new_cell = $objWorksheet->getCell($ColumnR.$RowR);
											if(!$new_cell->isInRange($my_merge))
											{
												$mergeColumn[$searchValue]['Last'] = $LastColumn;
												break;
											}													
										}
									}			
								}
							}
						}	
					}
					continue;
				}
				$objWorksheet->insertNewRowBefore($NextRow, 1);
				$i=0;
				foreach($mergeColumn as $name_cell)
				{
					//if($i==2)die();
					
					$objWorksheet->mergeCells($name_cell['First'].$NextRow.":".$name_cell['Last'].$NextRow);
					$i++;
				}
				foreach($arrV as $key=>$value)
				{		
					if($Column[$key]){
						
						$objWorksheet->setCellValue($Column[$key].$NextRow, $value);
					}
				}
				$NextRow++;
				
			}
		}
		/*foreach(range('1','100') as $ROW) {
		$objWorksheet->getRowDimension($ROW)
			->setRowHeight(-1);
			imagettfbbox ( float $size , float $angle , string $fontfile , string $text );
		}*/
	return $objWorksheet;
}
function PrepareArayToXLS($entity,$invoice_id){
	$ArrayRus=UpdateArrayValue(getEntityMapUnit($entity,$invoice_id));
	foreach($ArrayRus as $key => $value){
		$newArrayXLS['{'.$key.'}']=$value;
	}
	//print_r($ArrayRus);
	$prod=productExelTable($entity,$invoice_id);
	$newArrayXLS=array_merge($newArrayXLS,$prod);
	return $newArrayXLS;
}
function UpdateArrayKey($RusArray){
$array=explode('\r',$GLOBALS['text']);
	
	foreach($array as $val){
		$recAr=explode(';',trim($val));
		$NewArray[$recAr[0]]=$recAr[1];
	}
	foreach($RusArray as $k =>$v){
		foreach($NewArray as $k2 =>$v2){
			if($k==$k2){
				unset($RusArray[$k]);
				$RusArray[$v2]=$v;
			}
		}
	}
	return $RusArray;
}

function getCIBlockMapUnit(){
	CModule::IncludeModule('lists');
	$obList = new CList($GLOBALS['CIblockId']);
	$propertyValuesObject = \CIblockElement::getPropertyValues($GLOBALS['CIblockId'],array("ID" => $GLOBALS['ElIblockID'], "SHOW_NEW" => "Y" ));
		while($propertyValues = $propertyValuesObject->fetch())
		{
			foreach($propertyValues as $propertyId => $propertyValue)
			{
				if($propertyId == "IBLOCK_ELEMENT_ID")
					continue;
				$listValues['PROPERTY_'.$propertyId] = $propertyValue;	
			}
		}
		$arResult["FIELDS"] =  $obList->GetFields();
		foreach($arResult["FIELDS"] as $fieldId => $field)
			{
				$field["IBLOCK_ID"] = $GLOBALS['CIblockId'];
				$field["SECTION_ID"] = $iblockSectionId;
				$field["ELEMENT_ID"] = $GLOBALS['ElIblockID'];
				$field["FIELD_ID"] = $fieldId;
				$valueKey = (substr($fieldId, 0, 9) == "PROPERTY_") ? $fieldId : "~".$fieldId;
				$field["VALUE"] = $listValues[$valueKey];
				$result[$field['NAME']]=trim(\Bitrix\Lists\Field::renderField($field));
			
			//break;
			}
print_r($result);
}
function addFileToList($FileArray){
		
		$obList = new CList($GLOBALS['CIblockId']);
		$arResult =  $obList->GetFields();
		foreach($arResult as $property => $value){
			if($value['CODE']=='FAYL_DOKUMENTA'){
				$el = new CIBlockElement;
				$el->SetPropertyValues($GLOBALS['ElIblockID'], $GLOBALS['CIblockId'], $FileArray, 'FAYL_DOKUMENTA');
			}
		}
	}
	//addFileToList();
function getProductR($entity,$invoice_id){
	if($entity=="INVOICE"){
		$ProductArray = CCrmInvoice::GetProductRows($invoice_id);
	}
	elseif($entity=="DEAL"){
		$ProductArray = CCrmDeal::LoadProductRows($invoice_id);
	}
	//COption::SetOptionString('crm', 'default_product_catalog_id', 132);
	$catalogId=COption::GetOptionInt('crm', 'default_product_catalog_id');
	foreach($ProductArray as $key => $ProductArrayItem){
		$arFilter = Array("IBLOCK_ID"=>$catalogId,'ID'=>$ProductArrayItem['PRODUCT_ID'], "ACTIVE"=>"Y");
		$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect)->Fetch();
		if($res['PREVIEW_PICTURE']){
			$ProductArray[$key]['PREVIEW_PICTURE']=CFile::GetPath($res['PREVIEW_PICTURE']);
		}
		if($res['DETAIL_PICTURE']){
			$ProductArray[$key]['DETAIL_PICTURE']=CFile::GetPath($res['DETAIL_PICTURE']);
		}
		
	}
	return $ProductArray;
}
/*if(stripos($GLOBALS['Template'], 'xlsx')!==false){

	$arr=getFoldersObject();
	$FileTemplates=GetFileObj($GLOBALS['Template'],$arr['FolderTemplates']);
	$name = UpdateTemplatesXLS(PrepareArayToXLS($entity,$id),$FileTemplates); 
	$folderget=GetFolderOrCreate($arr['FolderGroup'],str_replace([':','@',',','.','~','^','-','/','\\'], '_', $GLOBALS['CompanyName']));
	$file=SetFileObj($GLOBALS['Template'],$folderget);
	addFileToList($file);
}
elseif(stripos($GLOBALS['Template'], 'docx')!==false){
	$arr=getFoldersObject();
	$FileTemplates=GetFileObj($GLOBALS['Template'],$arr['FolderTemplates']);
	$name=UpdateTemplatesDocx(UpdateArrayValue(getEntityMapUnit($entity,$id)),$FileTemplates);
	//print_r();
	$folderget=GetFolderOrCreate($arr['FolderGroup'],str_replace([':','@',',','.','~','^','-','/','\\'], '_', $GLOBALS['CompanyName']));
	$file=SetFileObj($GLOBALS['Template'],$folderget);
	addFileToList($file);
}*/


//getProductR(800);



//$CIblockId
//$arr=GetCIBLockRusName(132);

//getCIBlockMapUnit();
//$arr=GetProductList('DEAL',1331);
//$arr=UpdateArrayValue(getEntityMapUnit('INVOICE',$id));
//$arr=UpdateArrayValue(getEntityMapUnit('DEAL',1313));
	//$arr=getCSocNetGroupID();
	
	 
	
	//$name=UpdateTemplatesDocx($x=UpdateArrayValue(getEntityMapUnit('INVOICE',$id)),$FileTemplates);
	
	//SetFileObj($name['NAME'],$folderget);
	//$arr=PrepareRequisiteList('INVOICE',800);
	//$arUserFields=(new CCrmFields($USER_FIELD_MANAGER, $entityType))->GetFields(); CCrmCompany::GetUserFields()
	//$arr=productExelTable(800);
//print_r($arr);	
//$name = CFile::GetPath($FileTemplates->getFileId());
//print_r(UpdateArrayKey(UpdateArrayValue(getEntityMapUnit('INVOICE',$id))));
//print_r(UpdateArrayKey(UpdateArrayValue(getEntityMapUnit($entity,$id))));
?>
<form action="" method="post">
 <form action="action.php" method="post">	
ID Счета <input type="text" name="INV" /><br>
ID Cделки <input type="text" name="DEAL" /><br>
<input type="radio" name="exel" value="true">Exel<Br>
<input type="radio" name="exel" value="false">Docx<Br>
<input type="submit" />
</form>
<?
if($_POST['INV']){
	if($_POST['exel']=='true'){
echo '<ul>';
		foreach(PrepareArayToXLS('INVOICE',$_POST['INV']) as $key => $value){
			if(is_array($value)){
				foreach($value as $key2 => $value2){
					
					if($key2 == 0){
						echo "<p>Массив товаров -- Только объединенные поля<p>";
						foreach($value2 as $key3 => $value3){	
						echo "<li>$key3=$value3</li>";
						}
					}
				}
			}
			else{
				echo "<li>$key=$value</li>";
			}
			
		}
echo '<ul/>';
	}
	else{
//print_r(UpdateArrayValue(getEntityMapUnit('INVOICE',$_POST['INV'])));
echo '<ul>';

		foreach(UpdateArrayValue(getEntityMapUnit('INVOICE',$_POST['INV'])) as $key => $value){
			if(is_array($value)){
				foreach($value as $key2 => $value2){
					
					///echo "<li>$key2 = $value2 </li>";
					
				}
			}
			else{
				echo "<li>\${".$key."} = $value</li>";
			}
			
		}
echo '<ul/>';
	}
}
elseif($_POST['DEAL']){
	if($_POST['exel']=='true'){
echo '<ul>';
		foreach(PrepareArayToXLS('DEAL',$_POST['DEAL']) as $key => $value){
			if(is_array($value)){
				foreach($value as $key2 => $value2){
					
					if($key2 == 0){
						echo "<p>Массив товаров -- Только объединенные поля<p>";
						foreach($value2 as $key3 => $value3){	
						echo "<li>$key3=$value3</li>";
						}
					}
				}
			}
			else{
				echo "<li>$key=$value</li>";
			}
			
		}
echo '<ul/>';
	}
	else{

echo '<ul>';
		foreach(UpdateArrayValue(getEntityMapUnit('DEAL',$_POST['DEAL'])) as $key => $value){
			if(is_array($value)){
				foreach($value as $key2 => $value2){
					
					///echo "<li>$key2 = $value2 </li>";
					
				}
			}
			else{
				echo "<li>\${".$key."} = $value</li>";
			}
			
		}
echo '<ul/>';
	}
	
}
?>
